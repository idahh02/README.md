<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Recipient Form Submission</title>
    <meta name="description" content="Recipient Form Submission">
    <meta name="keywords" content="form, submission, recipient">

    <link rel="icon" href="assets/img/icon.jpeg">

    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            background-color: #f0f5f9; /* Light blue background */
            font-family: 'Arial', sans-serif;
        }

        .white-box {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            text-align: center;
        }

        .submission-box {
            margin-top: 20px;
            color: #555555; /* Dark gray text color */
        }

        h2 {
            color: #2d3e50; /* Dark blue text color */
        }

        img {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
        }

        .btn {
            padding: 10px 20px;
            background-color: #6798a2;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #8bc4cf;
        }
    </style>
</head>

<body>
    <div class="white-box">
        <img src="assets/img/icon.jpeg" alt="Icon">
        <h2>Your Form Has Been Successfully Submitted!</h2>
        <div class="submission-box">
            <!-- Your submission content goes here -->
        </div>
        <button class="btn" onclick="window.location.href='{{ route('mainpage') }}';">Go Back to Home</button>

    </div>
</body>

</html>

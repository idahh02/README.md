<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UpdateBloodController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\BloodBagController;
use App\Http\Controllers\DonorController;
use App\Http\Controllers\RecipientController;

Route::get('/', function () {
    return view('mainpage');
})->name('mainpage');

Route::get('/donor', function () {
    return view('donor');
});

Route::get('/recipient', function () {
    return view('recipient');
});

Route::get('/submit', function () {
    return view('submit');
});

Route::get('/staff', function () {
    return view('staff');
});


Route::get('/donor', [PageController::class, 'donor']);
Route::get('/recipient', [PageController::class, 'recipient']);
Route::get('/staff', [PageController::class, 'staff']);

Route::get('/bloodbags', [BloodBagController::class, 'index'])->name('bloodbags.index');
Route::get('/bloodbags/{id}/edit', [BloodBagController::class, 'edit'])->name('bloodbags.edit');
Route::put('/bloodbags/{id}', [BloodBagController::class, 'update'])->name('bloodbags.update');

Route::put('/bloodbags/update/{id}', [BloodBagController::class, 'update'])->name('bloodbags.update');

Route::get('/profile', function () {
   return view('profile');
});

Route::get('/login', function () {
    return view('login');
});

Route::post('/login', [LoginController::class, 'login'])->name('login');

Route::resource('bloodtest', UpdateBloodController::class);

Route::resource('/add-donor', DonorController::class);

Route::resource('/add-recipient', RecipientController::class);




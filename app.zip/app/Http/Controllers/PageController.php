<?php

namespace App\Http\Controllers;
// use App\Models\Student;

use Illuminate\Http\Request;

class PageController extends Controller
{
    public function donor()
    {
        return view('donor');
    }

    public function recipient()
    {
        return view('recipient');
    }

    public function staff()
    {
        return view('login');
    }
}

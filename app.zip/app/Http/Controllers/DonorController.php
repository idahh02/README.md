<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\donor;

class DonorController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $donor = new donor();
        $donor->first_name=$request->first_name;
        $donor->last_name=$request->last_name;
        $donor->phone_no=$request->phone_no;
        $donor->email=$request->email;
        $donor->address=$request->address;
        $donor->gender=$request->gender;
        $donor->blood_type=$request->blood_type;
        $donor->date_of_birth=$request->date_of_birth;
        $donor->disease=$request->disease;
        $donor->allergies=$request->allergies;
        $donor->created_at=today();
        $donor->updated_at=today();
        $donor->save();
        return redirect('submit');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}

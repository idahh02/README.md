<?php $__env->startSection('bloodInventory'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Blood Bag Inventory</title>

    <style>

        body{

        }
        h1{
            font-weight: bold;
            font-family: "Monaco", monospace;
            color: #4d4d4d; /* Dark gray text color */
        }

        table.custom-table {
            background-color: #f2f2f2; /* Light gray background color */
            border-collapse: collapse;
            width: 80%;
            max-width: 800px;
            margin: auto;
            margin-top: 50px; /* Adjust the margin-top value as needed */

            height: 100%;
            border: 3px solid #000000;
            font-family: "Times New Roman", monospace;
            text-align:center;
        }

        .custom-table th,
        .custom-table td {
            border: 3px solid #000000;
            padding: 10px; /* Adjust padding for better spacing */
            background-color: #c5d4d7;
            color: black;
        }

        button.btn {
            background-color: #8bc4cf;
            padding: 8px 15px;
            width: 100px;
            font-weight: bold;
            font-family: "Monaco", monospace;
            color: black; /* White text color 8bc4cf 3ba7bd*/
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button.btn:hover {
            background-color: #6798a2;
        }

    </style>

</head>

<body>


    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Blood Bag Inventory</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/bloodtest">Home</a></li>
                        <li class="breadcrumb-item active "><a href="/bloodtest"></a>Blood Bag Information</li>
                  </ol>
            </nav>
          </div><!-- End Page Title -->

        <section class="section">
         <div class= "" class="row">

                <div class="card">
                    <div class="card-body">
                        <br>
                        <!-- Bordered Table -->
                        <br>
                        <table class="table custom-table table-hover" >

                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Blood Type</th>
                                    <th scope="col">No of Pack(s)</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $bloodBag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bloodBag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($bloodBag->blood_type); ?></td>
                                        <td><?php echo e($bloodBag->no_packs); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('bloodbags.edit', $bloodBag->id)); ?>" method="get" style="margin: 0;">
                                                <button class="btn" type="submit">Edit</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                        <!-- End Table with hoverable rows -->
                        <br> <br><br>
                    </div>
                </div>

            </div>

        </section>

    </main><!-- End #main -->


</body>

</html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newproject\newproject\resources\views/bloodbags.blade.php ENDPATH**/ ?>
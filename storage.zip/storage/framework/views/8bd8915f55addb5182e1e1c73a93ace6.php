<?php $__env->startSection('bloodInventory'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Blood Bag Inventory</title>

    <style>
     .custom-table {
            border-collapse: collapse; /* Ensure borders collapse for consistent styling */
            width: 70%;
            border: 2px solid #000000; /* Set your desired border color here */
            background-color: #c5106b;
        }

        .custom-table th,
        .custom-table td {
            border: 2px solid #000000; /* Set your desired border color here */
            /* padding: 8px; /* Add padding for better visual appeal */
            /* text-align: left; Adjust text alignment as needed */ */

        }

    </style>

</head>

<body>

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Blood Bag Inventory</h1>
      <nav>
        <ol class="breadcrumb">
         <li class="breadcrumb-item"><a href="/">Home</a></li>
         <li class="breadcrumb-item"><a href=""></a>Dashboard</li>
         <li class="breadcrumb-item active"><a href="/table"></a>Blood Bag Inventory</li>
         <li class="breadcrumb-item"><a href="/bloodtest"></a>Blood Bag Information</li>
       </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">

        

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Bordered Table</h5>
              <!-- Bordered Table -->
              <table class="table custom-table table-hover">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Blood Type</th>
                    <th scope="col">No of Pack(s)</th>
                    <th scope="col">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">1</th>
                    <td>O</td>
                    <td>Designer</td>
                    <td>28</td>
                  </tr>
                  <tr>
                    <th scope="row">2</th>
                    <td>A</td>
                    <td>Developer</td>
                    <td>35</td>
                  </tr>
                  <tr>
                    <th scope="row">3</th>
                    <td>B</td>
                    <td>Finance</td>
                    <td>45</td>
                  </tr>
                  <tr>
                    <th scope="row">4</th>
                    <td>AB</td>
                    <td>HR</td>
                    <td>34</td>
                  </tr>
                </tbody>
              </table>
              <!-- End Table with hoverable rows -->

            </div>
          </div>


        
      </div>
    </section>

  </main><!-- End #main -->


</body>

</html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newproject\newproject\resources\views/table.blade.php ENDPATH**/ ?>
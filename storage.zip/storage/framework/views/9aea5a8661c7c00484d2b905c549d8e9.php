<?php $__env->startSection('bloodTest'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Blood Bag Information</title>
</head>

<body>


  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Blood Bag Information </h1>

      <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/bloodtest">Home</a></li>
                <li class="breadcrumb-item active "><a href="/bloodtest"></a>Blood Bag Information</li>
          </ol>
      </nav>
    </div><!-- End Page Title -->

     <section class="section">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">DETAILS OF BLOOD BAG &emsp;&emsp;
                <a href="<?php echo e(url('bloodtest/create')); ?>" class="btn btn-primary btn-sm">INSERT</a>
              </h5>
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">Bag ID</th>
                    <th scope="col">Blood Type</th>
                    <th scope="col">Donation Date </th>
                    <th scope="col">Expiry Date</th>
                    <th scope="col">Test Result</th>
                    <th scope="col">Extra Notes</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                    <?php if(!empty($bloodBags)): ?>
                        <?php $__currentLoopData = $bloodBags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bloodBag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e($bloodBag->bagID); ?></td>
                            <td><?php echo e($bloodBag->blood_type); ?></td>
                            <td><?php echo e($bloodBag->donationDate); ?></td>
                            <td><?php echo e($bloodBag->expirydate); ?></td>
                            <td><?php echo e($bloodBag->test_result); ?></td>
                            <td><?php echo e($bloodBag->notes); ?></td>
                            <td>
                                <form action="<?php echo e(url('/bloodtest', $bloodBag->id)); ?>" method="POST" onsubmit="return confirm('Continue to delete?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <td>No data available</td>
                        <td>No data available</td>
                        <td>No data available</td>
                        <td>No data available</td>
                        <td>No data available</td>
                        <td>No data available</td>
                        <td>No data available</td>
                    <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </section>

  </main><!-- End #main -->

</body>

</html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newproject\newproject\resources\views/bloodtest.blade.php ENDPATH**/ ?>